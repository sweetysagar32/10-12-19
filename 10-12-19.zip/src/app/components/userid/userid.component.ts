import { Component, OnInit } from '@angular/core';
import { EmployeeDetails } from 'src/app/model/employeedetails';

@Component({
  selector: 'app-userid',
  templateUrl: './userid.component.html',
  styleUrls: ['./userid.component.css']
})
export class UseridComponent implements OnInit {
  Employees: EmployeeDetails[];
  constructor() { }

  ngOnInit() {
  }

}
