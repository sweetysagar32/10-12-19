import { Component, OnInit } from '@angular/core';
import { Login } from 'src/app/model/userlogin';
import { UserloginService } from 'src/app/service/userlogin.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  userName:String;
  logins:Login[];

  constructor(private userloginservice: UserloginService) { }

  ngOnInit() {
    this.userName = " ";
  }

  
  private searchCustomers() {
    this.userloginservice.getByUsename(this.userName)
      .subscribe(logins => this.logins = logins);
      console.log(this.logins);
  }
 
  onSubmit() {
    this.searchCustomers();
  }

}
