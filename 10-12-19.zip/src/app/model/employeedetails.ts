export class EmployeeDetails{
    id: number; 
    candidateName: String;
    idate: String;
    interName: String;
    location: String;
    totalExp: String;
    releventExp: String;
    skill:String;
    mode:String
}