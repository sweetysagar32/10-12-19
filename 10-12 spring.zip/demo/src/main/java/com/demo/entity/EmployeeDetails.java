package com.demo.entity;


import java.sql.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;

@Entity
public class EmployeeDetails {


	@Id
	@GeneratedValue
	private int id;
	private String candidateName;
	private String idate;
	private String interName;
	private String Mode;
	private String totalExp;
	private String releventExp;
	private String bu;
	private String skill;
	

	

	public String getBu() {
		return bu;
	}

	public void setBu(String bu) {
		this.bu = bu;
	}

	public String getMode() {
		return Mode;
	}

	public void setMode(String mode) {
		Mode = mode;
	}

	//	@OneToMany
////	(cascade=CascadeType.ALL, mappedBy="skillId",targetEntity=Skill.class)
//	@JoinTable(name = "skills", joinColumns = @JoinColumn(name = "id"), inverseJoinColumns = @JoinColumn(name = "skillId"))
//	private List<Skill> skills;
//
//	public List<Skill> getSkills() {
//		return skills;
//	}
//
//	public void setSkills(List<Skill> skills) {
//		this.skills = skills;
//	}
//
	public String getCandidateName() {
		return candidateName;
	}

	public String getIdate() {
		return idate;
	}

	public void setIdate(String idate) {
		this.idate = idate;
	}

	public void setCandidateName(String candidateName) {
		this.candidateName = candidateName;
	}

	public String getInterName() {
		return interName;
	}

	public void setInterName(String interName) {
		this.interName = interName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public String getTotalExp() {
		return totalExp;
	}

	public void setTotalExp(String totalExp) {
		this.totalExp = totalExp;
	}

	public String getReleventExp() {
		return releventExp;
	}

	public void setReleventExp(String releventExp) {
		this.releventExp = releventExp;
	}
	
	public String getskill() {
		return skill;
	}

	public void setSkill(String skill) {
		this.skill = skill;
	}
	@Override
	public String toString() {
		return "EmployeeDetails [id=" + id + ", candidateName=" + candidateName + ", idate=" + idate + ", interName="
				+ interName + ", Mode=" + Mode + ", totalExp=" + totalExp + ", releventExp=" + releventExp + ", bu="
				+ bu + ", Skill=" + skill + "]";
	}

	

	
	

}
